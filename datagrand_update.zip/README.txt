﻿train.csv：训练数据集。

test.txt：测试数据集，用户数为public.txt的一半。

news_info.csv：候选资讯内容数据。

candidate.txt：待推荐的用户ID，每行一个ID。

sample_submission.txt：提交结果样例。